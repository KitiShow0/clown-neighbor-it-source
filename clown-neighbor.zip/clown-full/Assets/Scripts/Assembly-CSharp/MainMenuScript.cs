using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenuScript : MonoBehaviour
{
	public static int lvlForLoading;

	public Slider VolumeSlide;

	public Toggle mute;

	public GameObject optionsWindow;

	public GameObject generalMenuWindow;

	public Button[] LevelsButtons;

	public Button[] LanguageButtons;

	public AudioSource m_AudioSource;

	public Button JoyButt;

	public Button SwButt;

	private void Awake()
	{
		m_AudioSource = GetComponent<AudioSource>();
		CheckStartSettings();
		UpdateLanguage();
		ChangeContr();
		for (int i = 1; i < LevelsButtons.Length; i++)
		{
			LevelsButtons[i].interactable = false;
			LevelsButtons[i].gameObject.transform.GetChild(0).gameObject.SetActive(false);
		}
		for (int j = 0; j < LanguageButtons.Length; j++)
		{
			LanguageButtons[j].interactable = false;
			LanguageButtons[j].gameObject.transform.GetChild(0).gameObject.SetActive(false);
		}
		CheckUnlockLvl();
		SetActiveContrTypeSign();
	}

	public void CheckStartSettings()
	{
		if (PlayerPrefs.GetInt("1stTimeInGame") == 0)
		{
			PlayerPrefs.SetInt("1stTimeInGame", 1);
			float value = 4.9f;
			PlayerPrefs.SetFloat("Sensitivity", value);
			PlayerPrefs.SetInt("Language", 0);
			PlayerPrefs.SetFloat("Volume", 1f);
			m_AudioSource.volume = 1f;
		}
		mute.isOn = false;
		m_AudioSource.volume = PlayerPrefs.GetFloat("Volume");
		VolumeSlide.value = PlayerPrefs.GetFloat("Volume");
		optionsWindow.SetActive(false);
		generalMenuWindow.SetActive(true);
	}

	public void SetActiveContrTypeSign()
	{
		SwButt.gameObject.transform.GetChild(0).gameObject.SetActive(false);
		JoyButt.gameObject.transform.GetChild(0).gameObject.SetActive(false);
		if (PlayerPrefs.GetInt("ContrType") == 0)
		{
			SwButt.gameObject.transform.GetChild(0).gameObject.SetActive(true);
			JoyButt.gameObject.transform.GetChild(0).gameObject.SetActive(false);
		}
		else if (PlayerPrefs.GetInt("ContrType") == 1)
		{
			SwButt.gameObject.transform.GetChild(0).gameObject.SetActive(false);
			JoyButt.gameObject.transform.GetChild(0).gameObject.SetActive(true);
		}
	}

	public void ChangeContr()
	{
		if (PlayerPrefs.GetInt("ContrType") == 0)
		{
			SwButt.interactable = false;
			JoyButt.interactable = true;
			SetActiveContrTypeSign();
		}
		else if (PlayerPrefs.GetInt("ContrType") == 1)
		{
			SwButt.interactable = true;
			JoyButt.interactable = false;
			SetActiveContrTypeSign();
		}
	}

	public void ChooseJoystContr()
	{
		PlayerPrefs.SetInt("ContrType", 1);
		ChangeContr();
	}

	public void ChooseSwContr()
	{
		PlayerPrefs.SetInt("ContrType", 0);
		ChangeContr();
	}

	private void Update()
	{
		if (mute.isOn)
		{
			VolumeSlide.value = 0f;
		}
		PlayerPrefs.SetFloat("Volume", VolumeSlide.value);
		m_AudioSource.volume = VolumeSlide.value;
	}

	public void UpdateLanguage()
	{
		for (int i = 0; i < LanguageButtons.Length; i++)
		{
			LanguageButtons[i].interactable = true;
			LanguageButtons[i].gameObject.transform.GetChild(0).gameObject.SetActive(false);
		}
		LanguageButtons[PlayerPrefs.GetInt("Language")].interactable = false;
		LanguageButtons[PlayerPrefs.GetInt("Language")].gameObject.transform.GetChild(0).gameObject.SetActive(true);
	}

	public void SetLanguage(int langNum)
	{
		PlayerPrefs.SetInt("Language", langNum);
		UpdateLanguage();
	}

	private void CheckUnlockLvl()
	{
		if (PlayerPrefs.GetInt("CompletedLevels") <= 14)
		{
			for (int i = 1; i < PlayerPrefs.GetInt("CompletedLevels") + 1; i++)
			{
				LevelsButtons[i].interactable = true;
				LevelsButtons[i].gameObject.transform.GetChild(0).gameObject.SetActive(true);
			}
		}
		if (PlayerPrefs.GetInt("CompletedLevels") == 15)
		{
			for (int j = 1; j < PlayerPrefs.GetInt("CompletedLevels"); j++)
			{
				LevelsButtons[j].interactable = true;
				LevelsButtons[j].gameObject.transform.GetChild(0).gameObject.SetActive(true);
			}
		}
	}

	public void LoadLevel(int lvlNum)
	{
		lvlForLoading = lvlNum;
		SceneManager.LoadScene("Loading");
	}

	public void OpenGeneralMenu()
	{
		generalMenuWindow.SetActive(true);
	}

	public void OpenStartGameWindow()
	{
		generalMenuWindow.SetActive(false);
	}

	public void OpenOptionsWindow()
	{
		optionsWindow.SetActive(true);
		UpdateLanguage();
	}

	public void CloseOptionsWindow()
	{
		optionsWindow.SetActive(false);
		UpdateLanguage();
	}

	public void QuitGame()
	{
		Application.Quit();
	}

	public void OtherApps()
	{
		Application.OpenURL("https://play.google.com/store/apps/developer?id=World+Games+Studios");
	}

	public void VoteApp()
	{
		Application.OpenURL("https://play.google.com/store/apps/details?id=com.hellobaldy.mathteacher.neighbor.education");
	}
}
