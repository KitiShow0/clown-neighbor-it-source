using UnityEngine;

public class MinimapCameraScript : MonoBehaviour
{
	public static int playerCurFloor = 1;

	public static int neighborCurFloor = 1;

	private Transform player;

	public GameObject enemyArrow;

	public GameObject upArr;

	public GameObject downArr;

	public float high = 110f;

	private void Start()
	{
		player = GameObject.Find("Player").transform;
		enemyArrow = GameObject.Find("EnemyArrow");
		upArr.SetActive(false);
		downArr.SetActive(false);
	}

	private void LateUpdate()
	{
		if (playerCurFloor < neighborCurFloor)
		{
			upArr.SetActive(true);
			upArr.transform.position = enemyArrow.transform.position;
		}
		else
		{
			upArr.SetActive(false);
		}
		if (playerCurFloor > neighborCurFloor)
		{
			downArr.SetActive(true);
			downArr.transform.position = enemyArrow.transform.position;
		}
		else
		{
			downArr.SetActive(false);
		}
		base.transform.position = player.transform.position + Vector3.up * high;
	}
}
