using UnityEngine;

public class Scaler : MonoBehaviour
{
}
