using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Logo : MonoBehaviour
{
	private void Start()
	{
		StartCoroutine(LoadMenu());
	}

	private IEnumerator LoadMenu()
	{
		while (Time.frameCount < 180)
		{
			yield return null;
		}
		SceneManager.LoadScene("MainMenu");
	}
}
