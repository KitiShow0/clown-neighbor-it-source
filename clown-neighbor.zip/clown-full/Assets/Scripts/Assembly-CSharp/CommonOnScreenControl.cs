using UnityEngine;

public class CommonOnScreenControl : MonoBehaviour
{
}
