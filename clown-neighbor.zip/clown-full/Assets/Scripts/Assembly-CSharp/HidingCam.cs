using UnityEngine;

public class HidingCam : MonoBehaviour
{
	public GameObject hidecamera;

	private void Start()
	{
		hidecamera = base.gameObject.transform.GetChild(0).gameObject;
		hidecamera.SetActive(false);
	}

	public void ActivateHideCamera()
	{
		hidecamera.SetActive(true);
	}

	public void DisActivateHideCamera()
	{
		hidecamera.SetActive(false);
	}
}
