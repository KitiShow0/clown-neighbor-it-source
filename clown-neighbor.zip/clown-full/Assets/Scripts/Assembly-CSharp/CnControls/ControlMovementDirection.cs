using System;

namespace CnControls
{
	[Flags]
	public enum ControlMovementDirection
	{
		Horizontal = 1,
		Vertical = 2,
		Both = 3
	}
}
