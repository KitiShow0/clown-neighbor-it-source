using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class ControlTypeScript : MonoBehaviour
{
	public Button JoyButt;

	public Button SwButt;

	public GameObject SwContr;

	public GameObject JoyContr;

	public static int conrolType;

	private void Start()
	{
		JoyButt.onClick.AddListener(ChooseJoystContr);
		SwButt.onClick.AddListener(ChooseSwContr);
		SetActiveContrTypeSign();
		ChangeContr();
	}

	public void SetActiveContrTypeSign()
	{
		SwButt.gameObject.transform.GetChild(0).gameObject.SetActive(false);
		JoyButt.gameObject.transform.GetChild(0).gameObject.SetActive(false);
		if (PlayerPrefs.GetInt("ContrType") == 0)
		{
			SwButt.gameObject.transform.GetChild(0).gameObject.SetActive(true);
			JoyButt.gameObject.transform.GetChild(0).gameObject.SetActive(false);
		}
		else if (PlayerPrefs.GetInt("ContrType") == 1)
		{
			SwButt.gameObject.transform.GetChild(0).gameObject.SetActive(false);
			JoyButt.gameObject.transform.GetChild(0).gameObject.SetActive(true);
		}
	}

	private IEnumerator ChangeContrDelay()
	{
		yield return new WaitForSeconds(1.1f);
		SwContr.SetActive(false);
		JoyContr.SetActive(false);
		yield return new WaitForSeconds(1.1f);
		if (PlayerPrefs.GetInt("ContrType") == 0)
		{
			SwContr.SetActive(true);
			JoyContr.SetActive(false);
		}
		else if (PlayerPrefs.GetInt("ContrType") == 1)
		{
			SwContr.SetActive(false);
			JoyContr.SetActive(true);
		}
	}

	public void ChangeContr()
	{
		if (PlayerPrefs.GetInt("ContrType") == 0)
		{
			SwButt.interactable = false;
			JoyButt.interactable = true;
			SetActiveContrTypeSign();
			conrolType = 0;
		}
		else if (PlayerPrefs.GetInt("ContrType") == 1)
		{
			SwButt.interactable = true;
			JoyButt.interactable = false;
			SetActiveContrTypeSign();
			conrolType = 1;
		}
		StartCoroutine(ChangeContrDelay());
	}

	public void ChooseJoystContr()
	{
		PlayerPrefs.SetInt("ContrType", 1);
		ChangeContr();
		conrolType = 1;
	}

	public void ChooseSwContr()
	{
		PlayerPrefs.SetInt("ContrType", 0);
		ChangeContr();
		conrolType = 0;
	}
}
