using UnityEngine;

public class LockControl : MonoBehaviour
{
	private DoorContrScript door;

	private Rigidbody rigidBod;

	private void Start()
	{
		door = GetComponentInParent<DoorContrScript>();
		rigidBod = GetComponent<Rigidbody>();
	}

	public void OpenLock()
	{
		door.lockOpened = true;
		base.gameObject.transform.parent = null;
		rigidBod.isKinematic = false;
		Object.Destroy(base.gameObject, 4.7f);
		base.gameObject.tag = "Untagged";
	}
}
