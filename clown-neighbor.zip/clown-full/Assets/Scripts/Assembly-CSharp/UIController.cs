using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityStandardAssets.Characters.FirstPerson;

public class UIController : MonoBehaviour
{
	public Slider sensSlide;

	public Slider volumeSlide;

	public Slider staminaSlide;

	public GameObject staminaSlideObj;

	public Slider forceSlider;

	public GameObject LevelPrefab;

	public Transform InstanceLevelPoint;

	public GameObject optionsWindow;

	public GameObject currentTasksWindow;

	public GameObject helpWindow;

	public GameObject tasksWindowAtStart;

	public GameObject UIWindow;

	public GameObject inGameUIWindow;

	public GameObject downUIWindow;

	public GameObject loseGameWindow;

	public GameObject winLvlWindow;

	public GameObject itemUIImage;

	public GameObject EatFoodButt;

	public GameObject keyUIImage;

	public GameObject openLockBut;

	public GameObject hideButt;

	public GameObject unHideButt;

	public GameObject doorButtObj;

	public Button objectPickButton;

	public Button objectDropButton;

	public GameObject activateObjButt;

	public GameObject disActivateObjButt;

	public GameObject moveJoyst;

	public GameObject viewJoyst;

	public GameObject jumpButt;

	public Text FoodNumberText;

	private FirstPersonController player;

	private void Awake()
	{
		Object.Instantiate(LevelPrefab, new Vector3(InstanceLevelPoint.position.x, InstanceLevelPoint.position.y, InstanceLevelPoint.position.z), InstanceLevelPoint.rotation);
	}

	private void Start()
	{
		player = GameObject.FindWithTag("Player").GetComponent<FirstPersonController>();
		optionsWindow.SetActive(false);
		currentTasksWindow.SetActive(false);
		helpWindow.SetActive(false);
		unHideButt.SetActive(false);
		hideButt.SetActive(false);
		EatFoodButt.SetActive(false);
		loseGameWindow.SetActive(false);
		winLvlWindow.SetActive(false);
		doorButtObj.SetActive(false);
		itemUIImage.SetActive(false);
		keyUIImage.SetActive(false);
		openLockBut.SetActive(false);
		objectPickButton.gameObject.SetActive(false);
		activateObjButt.SetActive(false);
		disActivateObjButt.SetActive(false);
		FoodNumberText.text = player.foodNumber.ToString();
		int num = 6;
		Object.Destroy(tasksWindowAtStart, num);
	}

	private void Update()
	{
	}

	public void OpenOptionsWindow()
	{
		optionsWindow.SetActive(true);
		player.UpdateSensitOptions();
		Time.timeScale = 0f;
	}

	public void CloseOptionsWindow()
	{
		optionsWindow.SetActive(false);
		player.UpdateSensitOptions();
		Time.timeScale = 1f;
	}

	public void OpenCurrentTasksWindow()
	{
		currentTasksWindow.SetActive(true);
		Time.timeScale = 0f;
	}

	public void ShowCommercial()
	{
		ADSControl.ShowSimpleAd();
	}

	public void CloseTasks()
	{
		currentTasksWindow.SetActive(false);
		Time.timeScale = 1f;
	}

	public void RestartGame()
	{
		Time.timeScale = 1f;
		ShowCommercial();
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
	}

	public void ExitToMenu()
	{
		Time.timeScale = 1f;
		SceneManager.LoadScene("MainMenu");
	}

	public void ContinueGame()
	{
		Time.timeScale = 1f;
		ADSControl.ShowRewardedVideo();
		if (player.currLvlNum == 15)
		{
			SceneManager.LoadScene("MainMenu");
			return;
		}
		MainMenuScript.lvlForLoading = player.currLvlNum + 1;
		SceneManager.LoadScene("Loading");
	}

	public void OpenHelpWindow()
	{
		helpWindow.SetActive(true);
		Time.timeScale = 0f;
	}

	public void CloseHelpWindow()
	{
		helpWindow.SetActive(false);
		Time.timeScale = 1f;
	}

	public void RateAppLink()
	{
		Application.OpenURL("https://play.google.com/store/apps/details?id=com.hellobaldy.mathteacher.neighbor.education");
	}
}
