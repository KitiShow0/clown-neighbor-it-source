using UnityEngine;
using UnityEngine.Advertisements;

public class ADSControl : MonoBehaviour
{
	private void Start()
	{
		Object.DontDestroyOnLoad(base.gameObject);
		if (PlayerPrefs.GetInt("AdsRemoved") == 0)
		{
			Advertisement.Initialize("2838582");
		}
	}

	public static void ShowSimpleAd()
	{
		if (PlayerPrefs.GetInt("AdsRemoved") == 0)
		{
			Advertisement.Show();
		}
	}

	public static void ShowRewardedVideo()
	{
		if (PlayerPrefs.GetInt("AdsRemoved") == 0)
		{
			if (Advertisement.IsReady("rewardedVideo"))
			{
				ShowOptions showOptions = new ShowOptions();
				showOptions.resultCallback = HandleShowResult;
				ShowOptions showOptions2 = showOptions;
				Advertisement.Show("rewardedVideo", showOptions2);
			}
			else
			{
				Advertisement.Show();
			}
		}
	}

	private static void HandleShowResult(ShowResult result)
	{
		switch (result)
		{
		}
	}
}
