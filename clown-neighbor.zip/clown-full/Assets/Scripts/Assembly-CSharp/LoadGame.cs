using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LoadGame : MonoBehaviour
{
	private int curHint;

	private bool interstitialShown;

	public Image loadingBar;

	public AudioSource m_AudioSource;

	public GameObject[] HintTexts;

	private void Awake()
	{
		m_AudioSource = GetComponent<AudioSource>();
		m_AudioSource.volume = PlayerPrefs.GetFloat("Volume");
		ShowHint();
		interstitialShown = false;
		loadingBar.fillAmount = 0f;
		StartCoroutine(LoadCor());
	}

	private IEnumerator LoadCor()
	{
		while (loadingBar.fillAmount < 0.99f)
		{
			float n = Random.Range(0.9f, 2.9f);
			yield return new WaitForSeconds(n);
			loadingBar.fillAmount += Random.Range(0.15f, 0.22f);
		}
		SceneManager.LoadScene(MainMenuScript.lvlForLoading.ToString());
	}

	public void ShowHint()
	{
		for (int i = 0; i < HintTexts.Length; i++)
		{
			HintTexts[i].SetActive(false);
		}
		curHint = Random.Range(0, HintTexts.Length);
		HintTexts[curHint].SetActive(true);
	}

	public void ShowCommercial()
	{
		interstitialShown = true;
		ADSControl.ShowSimpleAd();
	}
}
