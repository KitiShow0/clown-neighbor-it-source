using UnityEngine;

public class DoorContrScript : MonoBehaviour
{
	public bool doorOpened;

	public bool lockOpened = true;

	private Animator doorAnimator;

	private AudioSource soundSource;

	private void Start()
	{
		doorAnimator = GetComponent<Animator>();
		soundSource = GetComponent<AudioSource>();
	}

	public void OpenDoor()
	{
		doorAnimator.SetBool("OpenDoor", true);
		soundSource.Play();
		doorOpened = true;
	}

	public void CloseDoor()
	{
		doorAnimator.SetBool("OpenDoor", false);
		soundSource.Play();
		doorOpened = false;
	}
}
