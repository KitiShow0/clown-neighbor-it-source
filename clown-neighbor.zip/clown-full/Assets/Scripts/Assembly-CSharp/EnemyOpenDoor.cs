using UnityEngine;

public class EnemyOpenDoor : MonoBehaviour
{
	private DoorContrScript doorControl;

	private void Start()
	{
		doorControl = GetComponentInChildren<DoorContrScript>();
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.tag == "Enemy")
		{
			doorControl.OpenDoor();
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (other.tag == "Enemy")
		{
			doorControl.CloseDoor();
		}
	}
}
