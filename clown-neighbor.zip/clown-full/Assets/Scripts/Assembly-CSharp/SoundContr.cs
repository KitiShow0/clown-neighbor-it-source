using UnityEngine;

public class SoundContr : MonoBehaviour
{
	public AudioSource m_AudioSource;

	public AudioClip mainMusic;

	public AudioClip catchMusic;

	private void Awake()
	{
		m_AudioSource = GetComponent<AudioSource>();
		m_AudioSource.volume = PlayerPrefs.GetFloat("Volume");
	}

	public void PlayMusicSound()
	{
		m_AudioSource.clip = mainMusic;
		if (!m_AudioSource.isPlaying)
		{
			m_AudioSource.Play();
		}
	}

	public void PlayCatchSound()
	{
		m_AudioSource.clip = catchMusic;
		if (!m_AudioSource.isPlaying)
		{
			m_AudioSource.Play();
		}
	}
}
