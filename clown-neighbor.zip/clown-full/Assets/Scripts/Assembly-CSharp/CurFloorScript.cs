using UnityEngine;

public class CurFloorScript : MonoBehaviour
{
	public int floorNumber = 1;

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Enemy")
		{
			MinimapCameraScript.neighborCurFloor = floorNumber;
		}
		if (other.gameObject.tag == "Player")
		{
			MinimapCameraScript.playerCurFloor = floorNumber;
		}
	}
}
