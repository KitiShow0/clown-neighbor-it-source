using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityStandardAssets.CrossPlatformInput;
using UnityStandardAssets.Utility;

namespace UnityStandardAssets.Characters.FirstPerson
{
	[RequireComponent(typeof(CharacterController))]
	[RequireComponent(typeof(AudioSource))]
	public class FirstPersonController : MonoBehaviour
	{
		private Coroutine forceCor;

		public bool isChangingPower;

		private Slider throwPowerSlider;

		public float throwForce = 1f;

		public GameObject cutSceneObj;

		public bool hiding;

		private bool activateObjActivityMade;

		private bool disActivateObjActivityMade;

		private bool haveItemForActivate;

		private bool haveItemForDisActivate;

		private bool haveLoot;

		private bool listenOnTakeButt;

		private bool isRunning;

		private bool haveDoorKey;

		private bool ListenOnLock;

		private bool ListenOnDoor;

		public bool WinLevel;

		public bool LoseLevel;

		private bool holdingObject;

		public float stamina = 100f;

		private float maxStamina = 100f;

		private bool m_Jump;

		private float m_YRotation;

		private float m_StepCycle;

		private float m_NextStep;

		private bool m_Jumping;

		private bool m_PreviouslyGrounded;

		public int foodNumber;

		public int currLvlNum = 1;

		public float currentSpeed = 3f;

		private UIController uiControl;

		private Vector3 direction;

		public LayerMask playerLay;

		private Button doorButton;

		private Button lockBut;

		private DoorContrScript currentDoor;

		private LockControl currentLock;

		private GameObject objToPickUp;

		public GameObject LoseGameCamera;

		public GameObject activateObjActivity;

		public GameObject disActivateObjActivity;

		public HidingCam hideCamera;

		private Ray ray;

		private RaycastHit hit;

		public Transform objectPlaceTransform;

		private Slider staminaSlide;

		private GameObject staminaSlideObj;

		public AudioClip throwAudio;

		private Slider sensSlide;

		public AudioClip deathAudio;

		private Slider volumeSlide;

		public AudioClip eatAudio;

		private SoundContr soundManager;

		public AudioClip lockAudio;

		private Camera m_Camera;

		private AudioSource m_AudioSource;

		private Vector2 m_Input;

		private Vector3 m_MoveDir = Vector3.zero;

		private CharacterController m_CharacterController;

		private CollisionFlags m_CollisionFlags;

		private Vector3 m_OriginalCameraPosition;

		private float stamin1Coef = 9f;

		private float stamin2Coef = 25f;

		[SerializeField]
		private bool m_IsWalking;

		[SerializeField]
		private float m_WalkSpeed;

		[SerializeField]
		private float m_RunSpeed;

		[SerializeField]
		[Range(0f, 1f)]
		private float m_RunstepLenghten;

		[SerializeField]
		private float m_JumpSpeed;

		[SerializeField]
		private float m_StickToGroundForce;

		[SerializeField]
		private float m_GravityMultiplier;

		[SerializeField]
		private MouseLook m_MouseLook;

		[SerializeField]
		private bool m_UseFovKick;

		[SerializeField]
		private FOVKick m_FovKick = new FOVKick();

		[SerializeField]
		private bool m_UseHeadBob;

		[SerializeField]
		private CurveControlledBob m_HeadBob = new CurveControlledBob();

		[SerializeField]
		private LerpControlledBob m_JumpBob = new LerpControlledBob();

		[SerializeField]
		private float m_StepInterval;

		[SerializeField]
		private AudioClip[] m_FootstepSounds;

		[SerializeField]
		private AudioClip m_JumpSound;

		[SerializeField]
		private AudioClip m_LandSound;

		private void Awake()
		{
		}

		public void CheckStartSettings()
		{
			sensSlide.maxValue = 40f;
			volumeSlide.maxValue = 1f;
			sensSlide.value = 5f;
			sensSlide.value = PlayerPrefs.GetFloat("Sensitivity");
		}

		public void UpdateSensitOptions()
		{
			PlayerPrefs.SetFloat("Sensitivity", sensSlide.value);
			m_MouseLook.XSensitivity = sensSlide.value;
			float num = 0.6f;
			m_MouseLook.YSensitivity = sensSlide.value * num;
			PlayerPrefs.SetFloat("Volume", volumeSlide.value);
			soundManager.m_AudioSource.volume = PlayerPrefs.GetFloat("Volume");
			int num2 = 2;
			m_AudioSource.volume = PlayerPrefs.GetFloat("Volume") / (float)num2;
		}

		private void UpdateVolume()
		{
			m_AudioSource.volume = PlayerPrefs.GetFloat("Volume");
			volumeSlide.value = PlayerPrefs.GetFloat("Volume");
			soundManager.m_AudioSource.volume = PlayerPrefs.GetFloat("Volume");
		}

		private void Start()
		{
			foodNumber = 0;
			currLvlNum = int.Parse(SceneManager.GetActiveScene().name);
			uiControl = GameObject.Find("Canvas").GetComponent<UIController>();
			staminaSlide = uiControl.staminaSlide;
			staminaSlideObj = uiControl.staminaSlideObj;
			sensSlide = uiControl.sensSlide;
			volumeSlide = uiControl.volumeSlide;
			throwPowerSlider = uiControl.forceSlider;
			throwPowerSlider.maxValue = 2.3f;
			soundManager = GetComponentInChildren<SoundContr>();
			doorButton = uiControl.doorButtObj.GetComponent<Button>();
			staminaSlideObj.SetActive(false);
			CheckStartSettings();
			staminaSlide.maxValue = 1f;
			stamina = maxStamina;
			lockBut = uiControl.openLockBut.GetComponent<Button>();
			currLvlNum = int.Parse(SceneManager.GetActiveScene().name);
			LoseLevel = false;
			LoseGameCamera = GameObject.Find("GaOvCam");
			LoseGameCamera.SetActive(false);
			haveItemForActivate = false;
			haveItemForDisActivate = false;
			haveLoot = false;
			activateObjActivityMade = false;
			disActivateObjActivityMade = false;
			activateObjActivity.SetActive(false);
			uiControl.objectDropButton.gameObject.SetActive(false);
			holdingObject = false;
			m_CharacterController = GetComponent<CharacterController>();
			m_Camera = Camera.main;
			m_OriginalCameraPosition = m_Camera.transform.localPosition;
			m_FovKick.Setup(m_Camera);
			m_HeadBob.Setup(m_Camera, m_StepInterval);
			m_StepCycle = 0f;
			int num = 2;
			m_NextStep = m_StepCycle / (float)num;
			m_Jumping = false;
			m_AudioSource = GetComponent<AudioSource>();
			m_MouseLook.Init(base.transform, m_Camera.transform);
			UpdateSensitOptions();
			UpdateVolume();
		}

		private void Update()
		{
			direction = new Vector3(Screen.width / 2, Screen.height / 2);
			ray = m_Camera.ScreenPointToRay(direction);
			UpdateRayForObjects();
			UpdateRayForDoors();
			UpdateRayForLocks();
			staminaSlide.value = stamina / maxStamina;
			stamina += Time.deltaTime * stamin1Coef;
			if (stamina <= 0f)
			{
				stamina = 0f;
			}
			if (stamina >= maxStamina)
			{
				stamina = maxStamina;
				staminaSlideObj.SetActive(false);
			}
			else
			{
				staminaSlideObj.SetActive(true);
			}
			if (isRunning)
			{
				stamina -= Time.deltaTime * stamin2Coef;
			}
			RotateView();
			if (!m_Jump)
			{
				m_Jump = CrossPlatformInputManager.GetButtonDown("Jump");
			}
			if (!m_PreviouslyGrounded && m_CharacterController.isGrounded)
			{
				StartCoroutine(m_JumpBob.DoBobCycle());
				PlayLandingSound();
				m_MoveDir.y = 0f;
				m_Jumping = false;
			}
			if (!m_CharacterController.isGrounded && !m_Jumping && m_PreviouslyGrounded)
			{
				m_MoveDir.y = 0f;
			}
			m_PreviouslyGrounded = m_CharacterController.isGrounded;
			if (base.gameObject.transform.GetChild(0).transform.childCount == 2 && (objToPickUp.transform.position != objectPlaceTransform.transform.position || objToPickUp.transform.rotation != objectPlaceTransform.transform.rotation))
			{
				float num = 3f;
				objToPickUp.transform.position = Vector3.MoveTowards(objToPickUp.transform.position, objectPlaceTransform.transform.position, Time.deltaTime * num);
				objToPickUp.transform.rotation = Quaternion.Slerp(objToPickUp.transform.rotation, objectPlaceTransform.transform.rotation, Time.time * num / 2f);
				if (Vector3.Distance(objToPickUp.transform.position, objectPlaceTransform.transform.position) >= num)
				{
					objToPickUp.transform.position = objectPlaceTransform.transform.position;
					objToPickUp.transform.rotation = objectPlaceTransform.transform.rotation;
				}
			}
		}

		private void UpdateRayForObjects()
		{
			if (Physics.Raycast(ray, out hit, 2f))
			{
				if (hit.collider.gameObject.tag == "Pick" && !holdingObject)
				{
					objToPickUp = hit.collider.gameObject;
					uiControl.objectPickButton.gameObject.SetActive(true);
					if (!listenOnTakeButt)
					{
						uiControl.objectPickButton.onClick.AddListener(PickUpObject);
						listenOnTakeButt = true;
					}
				}
			}
			else
			{
				uiControl.objectPickButton.gameObject.SetActive(false);
			}
		}

		private void UpdateRayForDoors()
		{
			if (Physics.Raycast(ray, out hit, 2.8f, ~(int)playerLay))
			{
				if (hit.collider.gameObject.tag == "Door")
				{
					currentDoor = hit.collider.gameObject.GetComponent<DoorContrScript>();
					if (currentDoor.lockOpened)
					{
						uiControl.doorButtObj.SetActive(true);
					}
					if (!ListenOnDoor)
					{
						doorButton.onClick.AddListener(ControlDoor);
						ListenOnDoor = true;
					}
				}
				else
				{
					currentDoor = null;
					uiControl.doorButtObj.SetActive(false);
					doorButton.onClick.RemoveAllListeners();
					ListenOnDoor = false;
				}
			}
			else
			{
				currentDoor = null;
				uiControl.doorButtObj.SetActive(false);
				doorButton.onClick.RemoveAllListeners();
				ListenOnDoor = false;
			}
		}

		private void UpdateRayForLocks()
		{
			if (Physics.Raycast(ray, out hit, 2.5f, ~(int)playerLay))
			{
				if (hit.collider.gameObject.tag == "Lock")
				{
					if (haveDoorKey)
					{
						currentLock = hit.collider.gameObject.GetComponent<LockControl>();
						uiControl.openLockBut.SetActive(true);
						if (!ListenOnLock)
						{
							lockBut.onClick.AddListener(OpenLock);
							ListenOnLock = true;
						}
					}
				}
				else
				{
					currentLock = null;
					uiControl.openLockBut.SetActive(false);
					lockBut.onClick.RemoveAllListeners();
					ListenOnLock = false;
				}
			}
			else
			{
				currentLock = null;
				uiControl.openLockBut.SetActive(false);
				lockBut.onClick.RemoveAllListeners();
				ListenOnLock = false;
			}
		}

		private void PickUpObject()
		{
			if ((bool)objToPickUp.GetComponent<Rigidbody>())
			{
				int num = 10;
				objToPickUp.GetComponent<Rigidbody>().angularDrag = num;
				objToPickUp.GetComponent<Rigidbody>().drag = num;
				objToPickUp.GetComponent<Rigidbody>().useGravity = false;
				objToPickUp.GetComponent<Rigidbody>().mass = 0f;
			}
			holdingObject = true;
			objToPickUp.transform.position = objectPlaceTransform.position;
			objToPickUp.transform.localRotation = objectPlaceTransform.transform.rotation;
			objToPickUp.transform.parent = objectPlaceTransform.transform.parent;
			listenOnTakeButt = false;
			uiControl.objectPickButton.onClick.RemoveAllListeners();
			uiControl.objectPickButton.gameObject.SetActive(false);
			uiControl.objectDropButton.gameObject.SetActive(true);
			throwPowerSlider.gameObject.SetActive(false);
			if (objToPickUp.name == "ItemForActivate" && (currLvlNum == 10 || currLvlNum == 11))
			{
				uiControl.itemUIImage.SetActive(true);
				haveItemForActivate = true;
			}
		}

		private IEnumerator ChangeThrowPowerCor()
		{
			isChangingPower = true;
			throwPowerSlider.value = 0f;
			bool goup = true;
			while (throwPowerSlider.value <= 2.3f && goup)
			{
				yield return new WaitForSeconds(0.01f * Time.deltaTime);
				throwPowerSlider.value += 0.035f;
				if (throwPowerSlider.value >= 2.3f)
				{
					goup = false;
				}
			}
			while (throwPowerSlider.value >= 0f && !goup)
			{
				yield return new WaitForSeconds(0.01f * Time.deltaTime);
				throwPowerSlider.value -= 0.035f;
				if (throwPowerSlider.value <= 0f)
				{
					goup = true;
				}
			}
			isChangingPower = false;
			if (!isChangingPower)
			{
				forceCor = StartCoroutine(ChangeThrowPowerCor());
			}
		}

		public void DropButtonDown()
		{
			if (!isChangingPower)
			{
				forceCor = StartCoroutine(ChangeThrowPowerCor());
				throwPowerSlider.gameObject.SetActive(true);
			}
		}

		public void DropButtonUp()
		{
			StopCoroutine(forceCor);
			isChangingPower = false;
			throwForce = throwPowerSlider.value;
			throwPowerSlider.gameObject.SetActive(false);
			DropObject();
		}

		private void DropObject()
		{
			if ((bool)objToPickUp.GetComponent<Rigidbody>())
			{
				objToPickUp.GetComponent<Rigidbody>().useGravity = true;
				objToPickUp.GetComponent<Rigidbody>().mass = 1f;
				objToPickUp.GetComponent<Rigidbody>().drag = 0.05f;
				objToPickUp.GetComponent<Rigidbody>().angularDrag = 0f;
			}
			holdingObject = false;
			m_AudioSource.PlayOneShot(throwAudio);
			objToPickUp.transform.parent = null;
			float num = 10f;
			Vector3 vector = new Vector3(m_Camera.transform.forward.x * num, m_Camera.transform.forward.y + num / 2f, m_Camera.transform.forward.z * num);
			objToPickUp.GetComponent<Rigidbody>().AddForce(vector * throwForce, ForceMode.Impulse);
			listenOnTakeButt = false;
			if (objToPickUp.name == "ItemForActivate" && (currLvlNum == 10 || currLvlNum == 11))
			{
				uiControl.itemUIImage.SetActive(false);
				haveItemForActivate = false;
			}
			uiControl.objectDropButton.gameObject.SetActive(false);
		}

		private void PlayLandingSound()
		{
			m_AudioSource.clip = m_LandSound;
			m_AudioSource.Play();
			m_NextStep = m_StepCycle + 0.5f;
		}

		private void FixedUpdate()
		{
			if (LoseLevel)
			{
				currentSpeed = 0f;
				m_WalkSpeed = 0f;
			}
			else if (isRunning && stamina >= 0f)
			{
				currentSpeed = (m_WalkSpeed = 7f);
				GetInput(out currentSpeed);
			}
			else
			{
				m_WalkSpeed = (currentSpeed = 4.2f);
				GetInput(out currentSpeed);
			}
			Vector3 vector = base.transform.forward * m_Input.y + base.transform.right * m_Input.x;
			RaycastHit hitInfo;
			Physics.SphereCast(base.transform.position, m_CharacterController.radius, Vector3.down, out hitInfo, m_CharacterController.height / 2f, -1, QueryTriggerInteraction.Ignore);
			vector = Vector3.ProjectOnPlane(vector, hitInfo.normal).normalized;
			m_MoveDir.x = vector.x * currentSpeed;
			m_MoveDir.z = vector.z * currentSpeed;
			if (m_CharacterController.isGrounded)
			{
				m_MoveDir.y = 0f - m_StickToGroundForce;
				if (m_Jump)
				{
					m_MoveDir.y = m_JumpSpeed;
					PlayJumpSound();
					m_Jump = false;
					m_Jumping = true;
				}
			}
			else
			{
				m_MoveDir += Physics.gravity * m_GravityMultiplier * Time.fixedDeltaTime;
			}
			m_CollisionFlags = m_CharacterController.Move(m_MoveDir * Time.fixedDeltaTime);
			ProgressStepCycle(currentSpeed);
			UpdateCameraPosition(currentSpeed);
		}

		private void PlayJumpSound()
		{
			m_AudioSource.clip = m_JumpSound;
			m_AudioSource.Play();
		}

		private void ProgressStepCycle(float speed)
		{
			if (m_CharacterController.velocity.sqrMagnitude > 0f && (m_Input.x != 0f || m_Input.y != 0f))
			{
				m_StepCycle += (m_CharacterController.velocity.magnitude + speed * ((!m_IsWalking) ? m_RunstepLenghten : 1f)) * Time.fixedDeltaTime;
			}
			if (m_StepCycle > m_NextStep)
			{
				m_NextStep = m_StepCycle + m_StepInterval;
				PlayFootStepAudio();
			}
		}

		private void PlayFootStepAudio()
		{
			if (m_CharacterController.isGrounded)
			{
				int num = Random.Range(1, m_FootstepSounds.Length);
				m_AudioSource.clip = m_FootstepSounds[num];
				m_AudioSource.PlayOneShot(m_AudioSource.clip);
				m_FootstepSounds[num] = m_FootstepSounds[0];
				m_FootstepSounds[0] = m_AudioSource.clip;
			}
		}

		private void UpdateCameraPosition(float speed)
		{
			if (m_UseHeadBob)
			{
				Vector3 localPosition;
				if (m_CharacterController.velocity.magnitude > 0f && m_CharacterController.isGrounded)
				{
					m_Camera.transform.localPosition = m_HeadBob.DoHeadBob(m_CharacterController.velocity.magnitude + speed * ((!m_IsWalking) ? m_RunstepLenghten : 1f));
					localPosition = m_Camera.transform.localPosition;
					localPosition.y = m_Camera.transform.localPosition.y - m_JumpBob.Offset();
				}
				else
				{
					localPosition = m_Camera.transform.localPosition;
					localPosition.y = m_OriginalCameraPosition.y - m_JumpBob.Offset();
				}
				m_Camera.transform.localPosition = localPosition;
			}
		}

		private void GetInput(out float speed)
		{
			float axis = CrossPlatformInputManager.GetAxis("Horizontal");
			float y = (isRunning ? 1f : CrossPlatformInputManager.GetAxis("Vertical"));
			bool isWalking = m_IsWalking;
			speed = currentSpeed;
			m_Input = new Vector2(axis, y);
			if (m_Input.sqrMagnitude > 1f)
			{
				m_Input.Normalize();
			}
			if (m_IsWalking != isWalking && m_UseFovKick && m_CharacterController.velocity.sqrMagnitude > 0f)
			{
				StopAllCoroutines();
				StartCoroutine(m_IsWalking ? m_FovKick.FOVKickDown() : m_FovKick.FOVKickUp());
			}
		}

		private void RotateView()
		{
			m_MouseLook.LookRotation(base.transform, m_Camera.transform);
		}

		public void RunButtonDown()
		{
			isRunning = true;
		}

		public void RunButtonUp()
		{
			isRunning = false;
		}

		private void OnControllerColliderHit(ControllerColliderHit hit)
		{
			Rigidbody attachedRigidbody = hit.collider.attachedRigidbody;
			if (m_CollisionFlags != CollisionFlags.Below && !(attachedRigidbody == null) && !attachedRigidbody.isKinematic)
			{
				attachedRigidbody.AddForceAtPosition(m_CharacterController.velocity * 0.1f, hit.point, ForceMode.Impulse);
			}
		}

		public void ControlDoor()
		{
			if (currentDoor != null)
			{
				if (!currentDoor.doorOpened)
				{
					currentDoor.OpenDoor();
				}
				else
				{
					currentDoor.CloseDoor();
				}
			}
		}

		public void OpenLock()
		{
			if (currentLock != null)
			{
				currentLock.OpenLock();
				m_AudioSource.PlayOneShot(lockAudio);
				if (currLvlNum == 1 || currLvlNum == 5 || currLvlNum == 12)
				{
					WinGame();
				}
			}
		}

		private void OnTriggerEnter(Collider other)
		{
			if (other.name == "Bed")
			{
				uiControl.hideButt.SetActive(true);
				hideCamera = other.gameObject.GetComponent<HidingCam>();
			}
			if (other.name == "Key")
			{
				Object.Destroy(other.gameObject, 0.3f);
				uiControl.keyUIImage.SetActive(true);
				haveDoorKey = true;
			}
			if (other.name == "ItemForDisactivate")
			{
				if (currLvlNum == 4)
				{
					haveItemForActivate = true;
				}
				haveItemForDisActivate = true;
				Object.Destroy(other.gameObject, 0.4f);
				uiControl.itemUIImage.SetActive(true);
			}
			if (other.name == "Loot")
			{
				Object.Destroy(other.gameObject, 0.4f);
				haveLoot = true;
				uiControl.itemUIImage.SetActive(true);
			}
			if (other.name == "ActivateObj" && !activateObjActivityMade && haveItemForActivate)
			{
				uiControl.activateObjButt.SetActive(true);
			}
			if (other.name == "DisActivateObj" && !disActivateObjActivityMade && haveItemForDisActivate)
			{
				uiControl.disActivateObjButt.SetActive(true);
			}
			if (other.name == "Home")
			{
				if ((currLvlNum == 6 || currLvlNum == 7 || currLvlNum == 8 || currLvlNum == 9 || currLvlNum == 14) && haveLoot)
				{
					WinGame();
				}
				if (activateObjActivityMade && disActivateObjActivityMade && haveLoot)
				{
					WinGame();
				}
			}
			if (other.name == "Food")
			{
				foodNumber++;
				Object.Destroy(other.gameObject);
				uiControl.EatFoodButt.SetActive(true);
				uiControl.FoodNumberText.text = foodNumber.ToString();
			}
		}

		private void OnTriggerExit(Collider other)
		{
			if (other.name == "ActivateObj")
			{
				uiControl.activateObjButt.SetActive(false);
			}
			if (other.name == "DisActivateObj")
			{
				uiControl.disActivateObjButt.SetActive(false);
			}
			if (other.name == "Bed" && !hiding)
			{
				uiControl.hideButt.SetActive(false);
				hideCamera = null;
			}
		}

		public void Hide()
		{
			if (hideCamera != null)
			{
				Time.timeScale = 1f;
				hideCamera.ActivateHideCamera();
				hiding = true;
				uiControl.UIWindow.SetActive(false);
				uiControl.downUIWindow.SetActive(false);
				uiControl.inGameUIWindow.SetActive(false);
				uiControl.moveJoyst.SetActive(false);
				uiControl.viewJoyst.SetActive(false);
				uiControl.jumpButt.SetActive(false);
				uiControl.unHideButt.SetActive(true);
				uiControl.hideButt.SetActive(false);
			}
		}

		public void UnHide()
		{
			if (hideCamera != null)
			{
				Time.timeScale = 1f;
				hideCamera.DisActivateHideCamera();
				hiding = false;
				uiControl.unHideButt.SetActive(false);
				uiControl.UIWindow.SetActive(true);
				uiControl.downUIWindow.SetActive(true);
				uiControl.inGameUIWindow.SetActive(true);
				uiControl.moveJoyst.SetActive(true);
				if (PlayerPrefs.GetInt("ContrType") == 1)
				{
					uiControl.viewJoyst.SetActive(true);
				}
				uiControl.jumpButt.SetActive(true);
			}
		}

		public void EatFood()
		{
			if (foodNumber > 0)
			{
				foodNumber--;
				stamina += 25f;
				m_AudioSource.PlayOneShot(eatAudio);
			}
			uiControl.FoodNumberText.text = foodNumber.ToString();
			if (foodNumber <= 0)
			{
				uiControl.EatFoodButt.SetActive(false);
				uiControl.FoodNumberText.text = string.Empty;
			}
		}

		private IEnumerator StartActivateObjActivityCor()
		{
			activateObjActivity.SetActive(true);
			yield return new WaitForSeconds(10f);
			WinGame();
			activateObjActivity.SetActive(false);
		}

		public void ActivateObject()
		{
			activateObjActivityMade = true;
			uiControl.activateObjButt.SetActive(false);
			StartCoroutine(StartActivateObjActivityCor());
		}

		public void DisActivateObject()
		{
			disActivateObjActivityMade = true;
			disActivateObjActivity.SetActive(false);
			uiControl.disActivateObjButt.SetActive(false);
			if (currLvlNum == 2 || currLvlNum == 3 || currLvlNum == 7 || currLvlNum == 13 || currLvlNum == 15)
			{
				WinGame();
			}
			if (currLvlNum == 15)
			{
				StartCoroutine(Level15CutScene());
			}
		}

		private IEnumerator Level15CutScene()
		{
			cutSceneObj.SetActive(true);
			uiControl.moveJoyst.SetActive(false);
			uiControl.viewJoyst.SetActive(false);
			uiControl.jumpButt.SetActive(false);
			uiControl.UIWindow.SetActive(false);
			uiControl.inGameUIWindow.SetActive(false);
			uiControl.downUIWindow.SetActive(false);
			yield return new WaitForSeconds(10f);
			WinGame();
		}

		public void GameOver()
		{
			StartCoroutine(GameOverCor());
		}

		public void WinGame()
		{
			WinLevel = true;
			if (currLvlNum > PlayerPrefs.GetInt("CompletedLevels"))
			{
				PlayerPrefs.SetInt("CompletedLevels", currLvlNum);
			}
			if (currLvlNum == 12)
			{
				StartCoroutine(WinGameLongCor());
			}
			else
			{
				StartCoroutine(WinGameCor());
			}
		}

		private IEnumerator WinGameLongCor()
		{
			yield return new WaitForSeconds(19f);
			uiControl.winLvlWindow.SetActive(true);
		}

		private IEnumerator WinGameCor()
		{
			yield return new WaitForSeconds(5f);
			uiControl.winLvlWindow.SetActive(true);
		}

		private IEnumerator GameOverCor()
		{
			LoseLevel = true;
			uiControl.moveJoyst.SetActive(false);
			uiControl.viewJoyst.SetActive(false);
			uiControl.jumpButt.SetActive(false);
			uiControl.UIWindow.SetActive(false);
			uiControl.inGameUIWindow.SetActive(false);
			uiControl.downUIWindow.SetActive(false);
			if (holdingObject)
			{
				objToPickUp.SetActive(false);
			}
			LoseGameCamera.SetActive(true);
			m_AudioSource.PlayOneShot(deathAudio);
			float catchingTime = 3.5f;
			yield return new WaitForSeconds(catchingTime);
			uiControl.loseGameWindow.SetActive(true);
			LoseGameCamera.SetActive(false);
		}
	}
}
