using UnityEngine;

public class BreakGlassScript : MonoBehaviour
{
	private GameObject solidGlass;

	private GameObject brokenGlass;

	private AudioSource soundSource;

	private bool GlassBroken;

	private void Start()
	{
		soundSource = GetComponent<AudioSource>();
		solidGlass = base.gameObject.transform.GetChild(0).gameObject;
		brokenGlass = base.gameObject.transform.GetChild(1).gameObject;
		brokenGlass.SetActive(false);
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Pick" && other.gameObject.GetComponent<Rigidbody>().useGravity && !GlassBroken)
		{
			solidGlass.SetActive(false);
			soundSource.Play();
			GlassBroken = true;
			brokenGlass.SetActive(true);
			Object.Destroy(brokenGlass, 8f);
		}
	}
}
