using UnityEngine;
using UnityEngine.UI;

public class LocalScript : MonoBehaviour
{
	public string EngText;

	public string SpText;

	public string RusText;

	public string GerText;

	public string ItText;

	public string ChText;

	public string JapText;

	public string ArabText;

	public string KorText;

	public string FrText;

	private Text curText;

	private void OnEnable()
	{
		curText = GetComponent<Text>();
		InvokeRepeating("UpdateLang", 0f, 3f);
	}

	public void UpdateLang()
	{
		switch (PlayerPrefs.GetInt("Language"))
		{
		case 0:
			curText.text = EngText;
			break;
		case 1:
			curText.text = RusText;
			break;
		case 2:
			curText.text = SpText;
			break;
		case 3:
			curText.text = GerText;
			break;
		case 4:
			curText.text = ItText;
			break;
		case 5:
			curText.text = ChText;
			break;
		case 6:
			curText.text = JapText;
			break;
		case 7:
			curText.text = ArabText;
			break;
		case 8:
			curText.text = KorText;
			break;
		case 9:
			curText.text = FrText;
			break;
		}
	}
}
