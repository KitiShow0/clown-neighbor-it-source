using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuLoad : MonoBehaviour
{
	private void LoadGeneralMenuScene()
	{
		SceneManager.LoadScene("MainMenu");
	}

	private void Awake()
	{
		Invoke("LoadGeneralMenuScene", 2.8f);
	}
}
