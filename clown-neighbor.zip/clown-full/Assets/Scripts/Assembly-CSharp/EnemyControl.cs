using System.Collections;
using UnityEngine;
using UnityEngine.AI;
using UnityStandardAssets.Characters.FirstPerson;

public class EnemyControl : MonoBehaviour
{
	public GameObject[] stopPoints;

	private int curStopPoint;

	private bool attacking;

	private bool stopping;

	private bool dizzy;

	private bool catching;

	public float seeRadius = 30f;

	public float stopDistance = 0.6f;

	private AudioSource soundSourse;

	public LayerMask playerLayer;

	private SoundContr soundControl;

	private NavMeshAgent navMesh;

	private Transform playerPosition;

	private Animator enemyAnimator;

	private FirstPersonController player;

	public AudioClip stepSound;

	private void Start()
	{
		player = GameObject.FindWithTag("Player").GetComponent<FirstPersonController>();
		playerPosition = GameObject.FindWithTag("Player").transform;
		soundSourse = GetComponent<AudioSource>();
		soundControl = GameObject.FindWithTag("Player").GetComponentInChildren<SoundContr>();
		navMesh = GetComponent<NavMeshAgent>();
		enemyAnimator = GetComponent<Animator>();
		curStopPoint = 0;
		stopDistance = 3.05f;
	}

	private void Update()
	{
		PlayStepSound();
		MoveAround();
		UpdateViewRay();
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Pick" && other.gameObject.GetComponent<Rigidbody>().useGravity && !dizzy && other.gameObject.GetComponent<Rigidbody>().velocity.magnitude > 2.8f)
		{
			StartCoroutine(DizzyCor());
		}
	}

	private void PlayStepSound()
	{
		if ((double)Mathf.Abs(navMesh.velocity.magnitude) > 0.21 && !soundSourse.isPlaying)
		{
			soundSourse.clip = stepSound;
			soundSourse.Play();
		}
	}

	private void MoveAround()
	{
		if (!attacking && !dizzy && stopPoints.Length > 0)
		{
			if (!stopping)
			{
				navMesh.SetDestination(stopPoints[curStopPoint].transform.position);
				enemyAnimator.SetFloat("WalkSpeed", navMesh.velocity.magnitude);
			}
			if (Vector3.Distance(stopPoints[curStopPoint].transform.position, base.transform.position) < 0.51f && !stopping)
			{
				enemyAnimator.SetFloat("WalkSpeed", 0f);
				StartCoroutine(StoppingCor());
			}
		}
	}

	private IEnumerator DizzyCor()
	{
		navMesh.speed = 0f;
		dizzy = true;
		enemyAnimator.SetBool("Dizzy", true);
		yield return new WaitForSeconds(Random.Range(2.8f, 7.2f));
		enemyAnimator.SetBool("Dizzy", false);
		dizzy = false;
	}

	private IEnumerator StoppingCor()
	{
		stopping = true;
		soundSourse.volume = PlayerPrefs.GetFloat("Volume");
		yield return new WaitForSeconds(Random.Range(1.1f, 5.2f));
		curStopPoint = Random.Range(0, stopPoints.Length);
		stopping = false;
	}

	private IEnumerator CatchingCor()
	{
		if (!player.hiding)
		{
			catching = true;
			yield return new WaitForSeconds(13.5f);
			catching = false;
		}
	}

	private void UpdateViewRay()
	{
		Vector3 vector = playerPosition.position - base.transform.position;
		float num = Vector3.Angle(vector, base.transform.forward);
		Ray ray = new Ray(base.transform.position + Vector3.up, vector);
		RaycastHit hitInfo;
		if (!Physics.Raycast(ray, out hitInfo, seeRadius, ~(int)playerLayer))
		{
			return;
		}
		if (hitInfo.transform.gameObject == playerPosition.gameObject && !dizzy && num < 161f && !catching && !player.hiding)
		{
			if (!catching)
			{
				StartCoroutine(CatchingCor());
			}
		}
		else if (!catching && !dizzy)
		{
			navMesh.speed = 2f;
			attacking = false;
			soundControl.PlayMusicSound();
		}
		if (!catching || dizzy)
		{
			return;
		}
		if (!player.hiding && Vector3.Distance(base.transform.position, playerPosition.transform.position) < stopDistance)
		{
			navMesh.stoppingDistance = 3.2f;
			enemyAnimator.SetFloat("WalkSpeed", 0f);
			if (!player.LoseLevel && !player.WinLevel)
			{
				player.GameOver();
			}
		}
		stopping = false;
		attacking = true;
		navMesh.SetDestination(playerPosition.position);
		navMesh.speed = 5f;
		enemyAnimator.SetFloat("WalkSpeed", navMesh.velocity.magnitude);
		if (!player.WinLevel)
		{
			soundControl.PlayCatchSound();
		}
	}
}
